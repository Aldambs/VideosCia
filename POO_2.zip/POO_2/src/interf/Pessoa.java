package interf;

public interface Pessoa {    
    public void andar();
    public void dormir();
       
}
