package interf;

import interf.BichodoMato;
import interf.Pessoa;
import java.util.Date;

public class Aluno extends Thread implements Pessoa, BichodoMato{

    @Override
    public void andar() {
        
    }
    
    @Override
    public void dormir() {
        
    }

    @Override
    public void processarProf() {
        
    }

 
    boolean getNome() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
