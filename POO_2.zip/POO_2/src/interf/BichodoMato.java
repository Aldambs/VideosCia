package interf;

public interface BichodoMato {
    public void processarProf();
}
