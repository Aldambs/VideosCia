package interf;

public class TesteJBDC {

    public static void main(String[] args) {
        try {
            String Drive = "";
            String url = "";
            String user = "";
            String pass = "";
            Class.forName(Drive);
            //connection con = DriverManager.getConnection(url, user, pass);
            //System.out.println(con.isClosed());
            
            Aluno a = new Aluno();
            a.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
