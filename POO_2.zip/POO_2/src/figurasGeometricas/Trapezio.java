package figurasGeometricas;

import br.com.geometria.FiguraGeometrica;
import java.awt.Graphics;
import java.awt.Polygon;

public class Trapezio extends FiguraGeometrica {
    private Triangulo t1, t2;
    private Retangulo r;
   
    private double baseMA, baseME, altura;

    /**
     *
     * @return
     */
    @Override
    public double calcularArea() {
        double area = 0;
        area = ((baseMA + baseME) / 2) * altura;
        return area;
    }

    @Override
    public void desenhar(Graphics g) {
        int[] xValues = { 50, 400, 150, 100, 200, 300 };
        int[] yValues = { 300, 200, 300, 200, 300, 200};
        Polygon poligono = new Polygon( xValues, yValues, 6 );
        g.drawPolygon( poligono );     
    }

    public double getBaseMA() {
        return baseMA;
    }

    public void setBaseMA(double baseMA) {
        this.baseMA = baseMA;
    }

    public double getBaseME() {
        return baseME;
    }

    public void setBaseME(double baseME) {
        this.baseME = baseME;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

}
