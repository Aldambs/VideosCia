package figurasGeometricas;

import br.com.geometria.FiguraGeometrica;
import java.awt.Graphics;

public class Triangulo extends FiguraGeometrica{
    private double base, altura;
    
    @Override
    public double calcularArea(){
        super.calcularArea();
        return (base * altura)/2;
    }
  
    @Override
    public void desenhar(Graphics g){
        int[] pontox = {50, 400, 150};
        int[] pontoy = {100, 200, 300};       
        g.drawPolygon(pontox, pontoy, pontox.length);      
    }
    
    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    
}
