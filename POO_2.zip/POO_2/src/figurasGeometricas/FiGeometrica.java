package figurasGeometricas;

import br.com.geometria.FiguraGeometrica;
import java.util.Scanner;

public class FiGeometrica extends FiguraGeometrica {

    public static void main(String[] args) {
        /*Object [] vetor = new Object[10]; Vetor generico comporta variados 
        tipos de atributos.*/
        Scanner ler = new Scanner(System.in);
        /*FiguraGeometrica[] figuras = new FiguraGeometrica[10];
        figuras[0] = new Triangulo();
        figuras[1] = new Quadrado();
        
        for (int i = 0; i <= figuras.length; i++) {
            FiguraGeometrica fg = figuras[i];
            if(fg != null){
                if(fg instanceof Triangulo){
                    System.out.println("Triangulo");
                }else if(fg instanceof Quadrado){
                    System.out.println("Quadrado");
                }
            }
        }
        */
        int op;

        do {
            System.out.println("Informe a opção: "
                    + "\n1. Circulo"
                    + "\n2. Quadrado"
                    + "\n3. Retângulo"
                    + "\n4. Trapézio"
                    + "\n5. Triângulo");
            op = ler.nextInt();

            switch (op) {
                case 1:
                    FiguraGeometrica fc = new Circulo();
                    Circulo c = (Circulo) fc;
                    System.out.println("Informe o raio: ");
                    c.setRaio(ler.nextDouble());
                    fc.setVisible(true);
                    System.out.printf("Area do circulo: %.2f \n", c.calcularArea());
                    break;
                    
                case 2:
                    FiguraGeometrica fq = new Quadrado();
                    Quadrado q = (Quadrado) fq;
                    System.out.println("Informe o lado: ");
                    q.setLado(ler.nextDouble());
                    fq.setVisible(true);
                    System.out.println("Area do quadrado: " + q.calcularArea());
                    break;

                case 3:
                    FiguraGeometrica fr = new Retangulo();
                    Retangulo r = (Retangulo) fr;
                    System.out.println("Informe o 1º lado: ");
                    r.setLado(ler.nextDouble());
                    System.out.println("Informe o 2º lado: ");
                    r.setLado2(ler.nextDouble());
                    fr.setVisible(true);
                    System.out.println("Area do retangulo: " + r.calcularArea());
                    break;

                case 4:
                    FiguraGeometrica ftr = new Trapezio();
                    Trapezio tr = (Trapezio) ftr;
                    System.out.println("Informe a altura: ");
                    tr.setAltura(ler.nextDouble());
                    System.out.println("Informe a base maior: ");
                    tr.setBaseMA(ler.nextDouble());
                    System.out.println("Informe a base menor: ");
                    tr.setBaseME(ler.nextDouble());
                    ftr.setVisible(true);
                    System.out.println("Area do trapezio: " + tr.calcularArea());
                    break;

                case 5:
                    FiguraGeometrica fg = new Triangulo();
                    Triangulo t = (Triangulo) fg;
                    System.out.println("Informe a altura: ");
                    t.setAltura(ler.nextDouble());
                    System.out.println("Informe a base: ");
                    t.setBase(ler.nextDouble());
                    fg.setVisible(true);
                    System.out.println("Area do triangulo: " + t.calcularArea());
                    break;
            }

        } while (op != 5);
    }
}
