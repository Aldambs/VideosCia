package figurasGeometricas;

public class Losango{
    
}
