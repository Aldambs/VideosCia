package figurasGeometricas;

import java.awt.Graphics;

public class Retangulo extends Quadrado{
    private double lado2;
    
    public Retangulo(double lado2, double lado) {
        super(lado);
        setLado(lado);
    }

    public Retangulo() {
    }
    
    @Override
    public double calcularArea(){
        super.calcularArea();
        return super.calcularArea() + (lado2 * lado2);
    }
    
    @Override
    public void desenhar(Graphics g){
        g.drawRect(300, 200, 300, 200);
    }
    
    public double getLado2() {
        return lado2;
    }

    public void setLado2(double lado2) {
        this.lado2 = lado2;
    }
    
}
