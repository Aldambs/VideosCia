package figurasGeometricas;

import br.com.geometria.FiguraGeometrica;
import java.awt.Graphics;

public class Quadrado extends FiguraGeometrica{
    private double lado;

    public Quadrado(double lado) {
        setLado(lado);
    }

    public Quadrado() {
    }
    
    @Override
    public double calcularArea(){
        super.calcularArea();
        return lado * lado;
    }   
    
    @Override
    public void desenhar(Graphics g){
        int[] pontox = {10, 10, 200, 200};
        int[] pontoy = {200, 10, 10, 200};   
        g.drawPolygon(pontox, pontoy, pontox.length);
    }
    public double getLado() {
        return lado;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }
    
}
