package figurasGeometricas;

import br.com.geometria.FiguraGeometrica;
import java.awt.Graphics;

public class Circulo extends FiguraGeometrica{
    private double raio;
    
     public Circulo(double raio) {
        setRaio(raio);
    }

    public Circulo() {
    }
  
    @Override
    public double calcularArea() {
        super.calcularArea();
        return Math.PI * Math.pow(raio, 2);
    }
    
    @Override
    public void desenhar(Graphics g){
        g.drawArc(270, 170, 100, 100, 0, 360);
       
    }
    
    public double getRaio() {
        return raio;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }
}


