package ativ;

public class Material implements MaterialDAO{
    private String IdProduto;
    private String DataAquisicao;
    private Lotacao[] elementos;
    private int tamanho;

    public Material(String IdProduto, String DataAquisicao, Lotacao[] elementos, int tamanho) {
        this.IdProduto = IdProduto;
        this.DataAquisicao = DataAquisicao;
        this.elementos = elementos;
        this.tamanho = tamanho;
    }

    public Material() {
    }
      
    public String getIdProduto() {
        return IdProduto;
    }

    public void setIdProduto(String idProduto) {
        IdProduto = idProduto;
    }

    public String getDataAquisicao() {
        return DataAquisicao;
    }

    public void setDataAquisicao(String dataAquisicao) {
        DataAquisicao = dataAquisicao;
    }
    
    public void Vetor(int capacidade) {
        this.elementos = new Lotacao[capacidade];
        this.tamanho = 0;
    }

    private Lotacao[] lotacoes = new Lotacao[10];
    private int indice = 0;

    public void adicionarLotacao(Lotacao lotacao) {
        if (indice < lotacoes.length) {
            lotacoes[indice++] = lotacao;
        }
    }

    public boolean adiciona(int posicao, Lotacao lotacao) {
        if (!(posicao >= 0 && posicao < tamanho)) {
            throw new IllegalArgumentException("Posição Inválida");
        }
        // mover elementos
        for (int i = this.tamanho - 1; i >= posicao; i--) {
            this.elementos[i + 1] = this.elementos[i];
        }
        this.elementos[posicao] = lotacao;
        this.tamanho++;

        return true;
    }

    public boolean adiciona(Lotacao lotacao) {
        if (this.tamanho < this.elementos.length) {
            this.elementos[this.tamanho] = lotacao;
            this.tamanho++;
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "\nCódigo do Produto = " + IdProduto 
                + "\nData de Aquisição = " + DataAquisicao;
    }

    @Override
    public void cadastrarMaterial() {
       
    }

    @Override
    public void consultar() {
       
    }

    @Override
    public void excluir() {
        
    }
    
    @Override
    public void alterar() {
        
    }
}
