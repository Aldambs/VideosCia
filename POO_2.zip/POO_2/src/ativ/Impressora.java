package ativ;

public class Impressora extends Equipamento{
    private boolean Colorida;
    private boolean Multifuncional;

    public Impressora() {
    }

    public Impressora(boolean Colorida, boolean Multifuncional, String Marca,
            String Modelo, String IdProduto, String DataAquisicao, 
            Lotacao[] elementos, int tamanho) {
        super(Marca, Modelo, IdProduto, DataAquisicao, elementos, tamanho);
        this.Colorida = Colorida;
        this.Multifuncional = Multifuncional;
    }

   
    public boolean isColorida() {
        return Colorida;
    }

    public void setColorida(boolean Colorida) {
        this.Colorida = Colorida;
    }

    public boolean isMultifuncional() {
        return Multifuncional;
    }

    public void setMultifuncional(boolean Multifuncional) {
        this.Multifuncional = Multifuncional;
    }

    @Override
    public String toString() {
        return super.toString() 
                + "\nColorida = " + Colorida 
                + "\nMultifuncional = " + Multifuncional;
    }
}
