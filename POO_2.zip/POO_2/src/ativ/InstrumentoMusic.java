package ativ;

public interface InstrumentoMusic {
    public void tocar();
}
