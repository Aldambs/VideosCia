package ativ;

public class Lotacao {

    private String DataLotacao;
    private String FimDelotacao;
    private Setor setor;
    private Material material;

    public Lotacao(String DataLotacao, String FimDelotacao, Setor setor, Material material) {
        this.DataLotacao = DataLotacao;
        this.FimDelotacao = FimDelotacao;
        this.setor = setor;
        this.material = material;
    }

    public Lotacao() {
    }

    
    public String getDataLotacao() {
        return DataLotacao;
    }

    public void setDataLotacao(String dataLotacao) {
        DataLotacao = dataLotacao;
    }

    public String getFimDelotacao() {
        return FimDelotacao;
    }

    public void setFimDelotacao(String fimDelotacao) {
        FimDelotacao = fimDelotacao;
    }

    public Setor getSetor() {
        return setor;
    }

    public void setSetor(Setor setor) {
        this.setor = setor;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    @Override
    public String toString() {
        return " " + setor + material
                + "\nData de Lotação = " + DataLotacao 
                + "\nFim De lotação = " + FimDelotacao;
    }

}
