package ativ;

public class Equipamento extends Material{
    private  String Marca;
    private String Modelo;

    public Equipamento(String Marca, String Modelo, String IdProduto, String DataAquisicao, Lotacao[] elementos, int tamanho) {
        super(IdProduto, DataAquisicao, elementos, tamanho);
        this.Marca = Marca;
        this.Modelo = Modelo;
    }

    public Equipamento() {
    }
  
    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }
   
    @Override
    public String toString() {
        return super.toString() 
                +"\nMarca = " + Marca 
                + "\nModelo = " + Modelo;
    }
    
}
