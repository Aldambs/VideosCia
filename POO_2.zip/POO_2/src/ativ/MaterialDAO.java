package ativ;

public interface MaterialDAO {
    public void cadastrarMaterial();
    public void consultar();
    public void excluir();
    public void alterar();
}
