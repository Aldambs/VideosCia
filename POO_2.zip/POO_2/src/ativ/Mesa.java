package ativ;

public class Mesa extends Material{
    private boolean TampaoVidro;
    private boolean Carteira;
    private String Fabricante;

    public Mesa(boolean TampaoVidro, boolean Carteira, String Fabricante, String IdProduto, String DataAquisicao, Lotacao[] elementos, int tamanho) {
        super(IdProduto, DataAquisicao, elementos, tamanho);
        this.TampaoVidro = TampaoVidro;
        this.Carteira = Carteira;
        this.Fabricante = Fabricante;
    }

    public Mesa() {
    }
    
    public boolean isTampaoVidro() {
        return TampaoVidro;
    }

    public void setTampaoVidro(boolean TampaoVidro) {
        this.TampaoVidro = TampaoVidro;
    }

    public boolean isCarteira() {
        return Carteira;
    }

    public void setCarteira(boolean Carteira) {
        this.Carteira = Carteira;
    }

    public String getFabricante() {
        return Fabricante;
    }

    public void setFabricante(String Fabricante) {
        this.Fabricante = Fabricante;
    }

    @Override
    public String toString() {
        return super.toString() 
                + "\nTampa de Vidro = " + TampaoVidro 
                + "\nCarteira = " + Carteira 
                + "\nFabricante = " + Fabricante;
    }
    
    
}
