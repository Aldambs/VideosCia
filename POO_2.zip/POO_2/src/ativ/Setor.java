package ativ;

import java.util.Arrays;

public class Setor {

    private String Nome;
    private Lotacao[] lotacoes = new Lotacao[10];
    private int indice = 0;

    public void adicionarLotacao(Lotacao lotacao) {
        if (indice < lotacoes.length) {
            lotacoes[indice++] = lotacao;
        }
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public int getIndice() {
        return indice;
    }

    public void setIndice(int indice) {
        this.indice = indice;
    }

    public Lotacao[] getLotacoes() {
        return lotacoes;
    }

    public void setLotacoes(Lotacao[] lotacoes) {
        this.lotacoes = lotacoes;
    }

    @Override
    public String toString() {
        return "\nNome do Setor = " + Nome;
    }
  
}
