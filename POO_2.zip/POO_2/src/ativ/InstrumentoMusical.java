package ativ;

public class InstrumentoMusical extends Equipamento{
     private String TipoInstrumento;
     private String nome;

    public InstrumentoMusical(String TipoInstrumento, String nome, 
            String Marca, String Modelo, String IdProduto, String DataAquisicao, 
            Lotacao[] elementos, int tamanho) {
        super(Marca, Modelo, IdProduto, DataAquisicao, elementos, tamanho);
        this.TipoInstrumento = TipoInstrumento;
        this.nome = nome;
    }

    public InstrumentoMusical() {
    }
    
    public String getTipoInstrumento() {
        return TipoInstrumento;
    }

    public void setTipoInstrumento(String TipoInstrumento){
        this.TipoInstrumento = TipoInstrumento;
    }

    @Override
    public String toString() {
        return super.toString() 
                + "\nNome do instrumento = " + nome
                + "\nTipo de Instrumento = " + TipoInstrumento;
    }
}
