package ativ;

public class Computador extends Equipamento{
    private String QtdMemoria;
    private String Processador;

    public Computador(String QtdMemoria, String Processador, String Marca, 
            String Modelo, String IdProduto, String DataAquisicao, 
            Lotacao[] elementos, int tamanho) {
        super(Marca, Modelo, IdProduto, DataAquisicao, elementos, tamanho);
        this.QtdMemoria = QtdMemoria;
        this.Processador = Processador;
    }

    public Computador() {
    }
    
    public String getQtdMemoria() {
        return QtdMemoria;
    }

    public void setQtdMemoria(String QtdMemoria) {
        this.QtdMemoria = QtdMemoria;
    }

    public String getProcessador() {
        return Processador;
    }

    public void setProcessador(String Processador) {
        this.Processador = Processador;
    }

    @Override
    public String toString() {
        return super.toString()
                + "\nQtd Memoria = " + QtdMemoria 
                + "\nProcessador=" + Processador;
    }
    
    
}
