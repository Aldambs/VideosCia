package ativ;

public class Relatorio {

    public static void main(String[] args) {   
        
        Setor sCoinf = new Setor();
        sCoinf.setNome("COINF");

        Setor sCCHS = new Setor();
        sCCHS.setNome("CCHS");

        Setor sGEN = new Setor();
        sGEN.setNome("GEN");
    
        Cadeira cadeira = new Cadeira();
        cadeira.setDataAquisicao("12/02/2018");
        cadeira.setFabricante("Verus");
        cadeira.setGiratoria(true);
        cadeira.setIdProduto("14785");
        cadeira.setRodas(true); 

        Lotacao l = new Lotacao();      
        l.setSetor(sCoinf);
        l.setMaterial(cadeira);
        l.setDataLotacao("22/02/2018");
        l.setFimDelotacao("10/06/2018");
        
        cadeira.adicionarLotacao(l);
        sCoinf.adicionarLotacao(l);
        
        Mesa mesa = new Mesa();
        mesa.setCarteira(false);
        mesa.setDataAquisicao("10/01/2018");
        mesa.setFabricante("Lenno");
        mesa.setIdProduto("25879");
        mesa.setTampaoVidro(false);
        
        Lotacao l1 = new Lotacao();      
        l1.setSetor(sCCHS);
        l1.setMaterial(mesa);
        l1.setDataLotacao("04/02/2018");
        l1.setFimDelotacao("10/05/2018");
 
        mesa.adicionarLotacao(l1);
        sCCHS.adicionarLotacao(l1);

        System.out.println(l.toString());
        System.out.println(l1.toString());

    }

}

