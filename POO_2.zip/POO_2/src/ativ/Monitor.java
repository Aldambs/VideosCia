package ativ;

public class Monitor extends Equipamento{
    public String Tamanho;

    public Monitor(String Tamanho, String Marca, String Modelo,
            String IdProduto, String DataAquisicao, Lotacao[] elementos, int tamanho) {
        super(Marca, Modelo, IdProduto, DataAquisicao, elementos, tamanho);
        this.Tamanho = Tamanho;
    }

    public Monitor() {
    }

    public String getTamanho() {
        return Tamanho;
    }

    public void setTamanho(String Tamanho) {
        this.Tamanho = Tamanho;
    }

    @Override
    public String toString() {
        return super.toString() 
                +"\nTamanho = " + Tamanho;
    }
    
    
}
