package ativ;

public class Roteador extends Equipamento{

    @Override
    public String toString() {
        return super.toString();
    }
    
}
