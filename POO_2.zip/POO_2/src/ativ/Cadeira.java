package ativ;

public class Cadeira extends Material {

    private String fabricante;
    private boolean rodas;
    private boolean giratoria;

    public Cadeira(String fabricante, boolean rodas, boolean giratoria, 
            String IdProduto, String DataAquisicao, Lotacao[] elementos, int tamanho) {
        super(IdProduto, DataAquisicao, elementos, tamanho);
        this.fabricante = fabricante;
        this.rodas = rodas;
        this.giratoria = giratoria;
    }

    public Cadeira() {
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public boolean isRodas() {
        return rodas;
    }

    public void setRodas(boolean rodas) {
        this.rodas = rodas;
    }

    public boolean isGiratoria() {
        return giratoria;
    }

    public void setGiratoria(boolean giratoria) {
        this.giratoria = giratoria;
    }

    @Override
    public String toString() {
        return super.toString()
                + "\nFabricante = " + getFabricante()
                + "\nRodas = " + isRodas()
                + "\nGiratoria = " + isGiratoria();
    }

}
