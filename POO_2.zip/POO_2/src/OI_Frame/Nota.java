package OI_Frame;

import java.io.Serializable;

public class Nota implements  Serializable{
    private double valor;

    /**
     * @return the valor
     */
    public double getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(double valor) {
        this.valor = valor;
    }
}

