/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OI_Frame;

import java.awt.GridLayout;
import java.awt.HeadlessException;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author ALDA MATOS
 */
public class FormCad extends FormBaseCRUD {

    private JTextField jtfNome = new JTextField();
    private JTextField jtfFone = new JTextField();
    private JTextField jtfMatricula = new JTextField();
    private JTextField jtfData = new JTextField();

    public FormCad() throws HeadlessException {
        setSize(400, 400);
        jpnCentro.setLayout(new GridLayout(4, 2));

        jpnCentro.add(new JLabel("Nome:"));
        jpnCentro.add(jtfNome);
        jpnCentro.add(new JLabel("Fone:"));
        jpnCentro.add(jtfFone);
        jpnCentro.add(new JLabel("Matricula:"));
        jpnCentro.add(jtfMatricula);
        jpnCentro.add(new JLabel("Data:"));
        jpnCentro.add(jtfData);

        jbtAlterar.setVisible(false);
        jbtExcluir.setVisible(false);

    }

}
