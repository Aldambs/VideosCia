/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OI_Frame;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author ALDA MATOS
 */
public class FormBaseCRUD extends JFrame {
    protected JPanel jpnNorte = new JPanel();
    protected JPanel jpnSul = new JPanel();
    protected JPanel jpnOeste = new JPanel();
    protected JPanel jpnLeste = new JPanel();
    protected JPanel jpnCentro = new JPanel();
    protected JButton jbtCadastrar = new JButton("Cadastrar");
    protected JButton jbtAlterar = new JButton("Alterar");
    protected JButton jbtExcluir = new JButton("Excluir");
    protected JButton jbtCancelar = new JButton("Cancelar");
    
    public FormBaseCRUD() throws HeadlessException {
        setLayout(new BorderLayout());
        getContentPane().add(jpnNorte, java.awt.BorderLayout.NORTH);
        getContentPane().add(jpnSul, java.awt.BorderLayout.SOUTH);
        getContentPane().add(jpnOeste, java.awt.BorderLayout.WEST);
        getContentPane().add(jpnLeste, java.awt.BorderLayout.EAST);
        getContentPane().add(jpnCentro, java.awt.BorderLayout.CENTER);
        
        jpnSul.setLayout(new FlowLayout());
        jpnSul.add(jbtCadastrar);
        jpnSul.add(jbtAlterar);
        jpnSul.add(jbtExcluir);
        jpnSul.add(jbtCancelar);
        
        jbtCancelar.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelarAction();
            }
        } );
    }   
    
    public void cancelarAction() {
        setVisible(false);
    }
}

