/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OI_Frame;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author ALDA MATOS
 */
public class Arquivos {
    private String path;
    private String nome;
    
    public void salvar(String str) throws Exception  {
        salvar(str.getBytes());
    }
    
    public void salvar(byte[] bytes) throws Exception  {
        File fPath = new File(getPath()); 
        if (!fPath.exists()) {
            fPath.mkdirs();
        }
        //File fArquivo = new File((path == null || path.trim().length() == 0)?"":(path + File.separator )+ nome);        ;
        File fArquivo = null;
        if (path == null || path.trim().length() == 0) {
            fArquivo = new File(nome);        
        } else {
            fArquivo = new File(path + File.separator + nome);        
        }
        
        FileOutputStream fos = new FileOutputStream(fArquivo);
        fos.write(bytes);
        fos.flush();
        fos.close();
    }    
    
    public String lerTexto() throws Exception{
        return new String(ler());
    }
    
    public byte[] ler() throws Exception{
        File fPath = new File(path); 
        if (!fPath.exists()) {
            throw new Exception("Arquivo inexistente: " + nome);
        }
        //File fArquivo = new File((path == null || path.trim().length() == 0)?"":(path + File.separator )+ nome);        ;
        File fArquivo = null;
        if (path == null || path.trim().length() == 0) {
            fArquivo = new File(nome);        
        } else {
            fArquivo = new File(path + File.separator + nome);        
        }
        
        FileInputStream fis = new FileInputStream(fArquivo);
        //fis.read();
        byte[] buffer = new byte[5];
        int controle = -1;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        while ( (controle = fis.read(buffer)) > 0) {
            byte[] bufferTemp = new byte[controle];
            System.arraycopy(buffer, 0, bufferTemp, 0, controle);
            baos.write(bufferTemp);
        }
        fis.close();
        return baos.toByteArray();
    }
    
    public Object lerObjeto() throws Exception {
        File fPath = new File(path); 
        if (!fPath.exists()) {
            throw new Exception("Arquivo inexistente: " + nome);
        }
        //File fArquivo = new File((path == null || path.trim().length() == 0)?"":(path + File.separator )+ nome);        ;
        File fArquivo = null;
        if (path == null || path.trim().length() == 0) {
            fArquivo = new File(nome);        
        } else {
            fArquivo = new File(path + File.separator + nome);        
        }
        FileInputStream fis = new FileInputStream(fArquivo);
        ObjectInputStream ois = new ObjectInputStream(fis);
        return ois.readObject();
    }
    
    public void salvarObjeto(Object o) throws Exception {
        File fPath = new File(getPath()); 
        if (!fPath.exists()) {
            fPath.mkdirs();
        }
        //File fArquivo = new File((path == null || path.trim().length() == 0)?"":(path + File.separator )+ nome);        ;
        File fArquivo = null;
        if (path == null || path.trim().length() == 0) {
            fArquivo = new File(nome);        
        } else {
            fArquivo = new File(path + File.separator + nome);        
        }

        FileOutputStream fos = new FileOutputStream(fArquivo);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(o);
        oos.flush();
        oos.close();
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the path
     */
    public String getPath() {
        return path;
    }

    /**
     * @param path the path to set
     */
    public void setPath(String path) {
        this.path = path;
    }
}


