package prova_Alda;

public class VeiculoDeCarga extends VeiculoMotorizado{
    private String cargaMaxima;
    private int numEixo;
    private boolean possuemAR;
    private String cambioAutomatico;
    private String direcao;
    private boolean som;
    private boolean cama;

    public VeiculoDeCarga() {
    }

    public VeiculoDeCarga(String cargaMaxima, int numEixo, boolean possuemAR, 
            String cambioAutomatico, String direcao, boolean som, boolean cama) {
        super();
        this.cargaMaxima = cargaMaxima;
        this.numEixo = numEixo;
        this.possuemAR = possuemAR;
        this.cambioAutomatico = cambioAutomatico;
        this.direcao = direcao;
        this.som = som;
        this.cama = cama;
    }

    public String getCargaMaxima() {
        return cargaMaxima;
    }

    public void setCargaMaxima(String cargaMaxima) {
        this.cargaMaxima = cargaMaxima;
    }

    public int getNumEixo() {
        return numEixo;
    }

    public void setNumEixo(int numEixo) {
        this.numEixo = numEixo;
    }

    public boolean isPossuemAR() {
        return possuemAR;
    }

    public void setPossuemAR(boolean possuemAR) {
        this.possuemAR = possuemAR;
    }

    public String getCambioAutomatico() {
        return cambioAutomatico;
    }

    public void setCambioAutomatico(String cambioAutomatico) {
        this.cambioAutomatico = cambioAutomatico;
    }

    public String getDirecao() {
        return direcao;
    }

    public void setDirecao(String direcao) {
        this.direcao = direcao;
    }

    public boolean isSom() {
        return som;
    }

    public void setSom(boolean som) {
        this.som = som;
    }

    public boolean isCama() {
        return cama;
    }

    public void setCama(boolean cama) {
        this.cama = cama;
    }

    @Override
    public String toString() {
        return super.toString()
                + "\nCarga Maxima = " + cargaMaxima 
                + "\nNúmero de Eixo = " + numEixo 
                + "\nPossuem AR = " + possuemAR 
                + "\nCambio Automatico = " + cambioAutomatico 
                + "\nDireção = " + direcao 
                + "\nSom = " + som 
                + "\nCama = " + cama;
    }
    
    
}
