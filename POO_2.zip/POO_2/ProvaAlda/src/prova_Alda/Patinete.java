package prova_Alda;

public class Patinete extends VeiculoNaoMotorizado{
    private int numRodas;

    public Patinete() {
    }

    public Patinete(int numRodas) {
        super();
        this.numRodas = numRodas;
    }
    
    public int getNumRodas() {
        return numRodas;
    }

    public void setNumRodas(int numRodas) {
        this.numRodas = numRodas;
    }

    @Override
    public String toString() {
        return  "\nNúmero de Rodas = " + numRodas;
    }
    
    
}
