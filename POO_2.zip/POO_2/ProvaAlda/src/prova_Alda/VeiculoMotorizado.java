package prova_Alda;

public class VeiculoMotorizado {
    private int potencia, qtd;
    private ProvaVeiculo[] veiculo;
    
    public VeiculoMotorizado() {
    }
    
    public VeiculoMotorizado(int potencia) {
        this.potencia = potencia;
        this.veiculo = new ProvaVeiculo[10];
    }
        
    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }
    
    public boolean cadastrarVeiculo(ProvaVeiculo veiculo) {
        //Analisa o espaço no vetor
        if (qtd >= this.veiculo.length) {
            return false;
        }else {
            //Adiciona um veiculo ao vetor
            this.veiculo[qtd] = veiculo;
            qtd++;
            
        }
        return true;        
    }
    
    @Override
    public String toString() {
        return "\nPotência = " + potencia;
    }
    
    
}
