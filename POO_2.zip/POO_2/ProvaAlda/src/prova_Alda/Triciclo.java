package prova_Alda;

public class Triciclo extends VeiculoNaoMotorizado{
    private String cor;

    public Triciclo() {
    }

    public Triciclo(String cor) {
        super();
        this.cor = cor;
    }
    
    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    @Override
    public String toString() {
        return  "\nCor = " + cor;
    }
    
    
}
