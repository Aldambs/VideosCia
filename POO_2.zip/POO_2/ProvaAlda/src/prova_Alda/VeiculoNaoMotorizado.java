package prova_Alda;

public class VeiculoNaoMotorizado {
    private int numPassageiros, qtd;
    private ProvaVeiculo[] veiculo;
    
    public VeiculoNaoMotorizado(int numPassageiros) {
        this.numPassageiros = numPassageiros;
        this.veiculo = new ProvaVeiculo[10];
    }
       
    public VeiculoNaoMotorizado() {
    }

    public int getNumPassageiros() {
        return numPassageiros;
    }

    public void setNumPassageiros(int numPassageiros) {
        this.numPassageiros = numPassageiros;
    }
    
    public boolean cadastrarVeiculo(ProvaVeiculo veiculo) {
        //Analisa o espaço no vetor
        if (qtd >= this.veiculo.length) {
            return false;
        }else {
            //Adiciona um veiculo ao vetor
            this.veiculo[qtd] = veiculo;
            qtd++;           
        }
        return true;
        
    }
    
    @Override
    public String toString() {
        return "\nNúmeros de Passageiros = " + numPassageiros;
    }
    
    
}
