package prova_Alda;

public class Bicicleta extends VeiculoNaoMotorizado{
    private int numOcupantes;
    private String tmAroRoda;

    public Bicicleta() {
    }

    public Bicicleta(int numOcupantes, String tmAroRoda) {
        super();
        this.numOcupantes = numOcupantes;
        this.tmAroRoda = tmAroRoda;
    }    

    public int getNumOcupantes() {
        return numOcupantes;
    }

    public void setNumOcupantes(int numOcupantes) {
        this.numOcupantes = numOcupantes;
    }

    public String getTmAroRoda() {
        return tmAroRoda;
    }

    public void setTmAroRoda(String tmAroRoda) {
        this.tmAroRoda = tmAroRoda;
    }

    @Override
    public String toString() {
        return super.toString() 
                +"\nNúmero de Ocupantes = " + numOcupantes 
                +"\nTamanho do Aro Roda = " + tmAroRoda;
    }
    
    
}
