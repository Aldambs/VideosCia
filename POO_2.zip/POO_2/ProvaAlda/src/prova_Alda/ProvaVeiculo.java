package prova_Alda;

public class ProvaVeiculo {

    public static void main(String[] args) {
        
        /*Veiculo[] lista = new Veiculo[10];
        lista[0] = new VeiculoDeCarga();
        lista[1] = new VeiculoDePessoas();
        lista[2] = new VeiculoCicloMotor();
        lista[3] = new VeiculoPasseio();
        lista[4] = new VeiculoUtilitario();
        lista[5] = new Bicicleta();
        lista[6] = new Patinete();
        lista[7] = new Triciclo();
        lista[8] = new VeiculoDeCarga();
        lista[9] = new Bicicleta();*/
        
        
        /*Object[] veiculos = new Object[10];
        int totalPess = 0;
 
        VeiculoCicloMotor VeiculoCicloMotor = new VeiculoCicloMotor();
        VeiculoDeTransporteDeCarga vTc = new VeiculoDeTransporteDeCarga();
        VeiculoPasseio veiculoPasseio = new VeiculoPasseio();
        VeiculoTransportePessoas vTp = new VeiculoTransportePessoas();
        VeiculoUtilitario veiculoUtilitario = new VeiculoUtilitario();
        Bicicleta bicicleta = new Bicicleta();
        Patinete patinete = new Patinete();
        Triciclo triciclo = new Triciclo();

        for (Object veiculo : veiculos) {
            if(veiculo instanceof VeiculoCicloMotor){
                totalPess =+ 1;
            }
            if(veiculo instanceof VeiculoDeTransporteDeCarga){
                totalPess =+ 1;
            }
            if (veiculo instanceof VeiculoPasseio) {
                totalPess = veiculoPasseio.getNumPessoas() + 1;               
            }
            if (veiculo instanceof VeiculoTransportePessoas) {
                totalPess = vTp.getNumMaxPessoas() + 1;               
            }
            if (veiculo instanceof VeiculoUtilitario) {
                totalPess =+ 1;
            }
            if (veiculo instanceof Bicicleta) {
                int soma = bicicleta.getNumOcupantes() + bicicleta.getNumPassageiros();
                totalPess = soma + 1;               
            }
            if (veiculo instanceof Triciclo) {
                totalPess = triciclo.getNumPassageiros() + 1;
            }
            if (veiculo instanceof Patinete) {
                totalPess = patinete.getNumPassageiros() + 1;
            }
        }*/
    }
}
