package prova_Alda;

public class VeiculoCicloMotor extends VeiculoMotorizado{
    private int cilindrada;
    private boolean ignicaoEletronica;

    public VeiculoCicloMotor() {
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    public boolean isIgnicaoEletronica() {
        return ignicaoEletronica;
    }

    public void setIgnicaoEletronica(boolean ignicaoEletronica) {
        this.ignicaoEletronica = ignicaoEletronica;
    }

    @Override
    public String toString() {
        return super.toString() + "\nCilindrada = " + cilindrada 
               +"\nIgnição Eletrônica = " + ignicaoEletronica;
    }
    
    
}
