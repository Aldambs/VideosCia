package prova_Alda;

public class VeiculoPasseio extends VeiculoMotorizado{
    private int numPessoas;
    private boolean possuemAR;
    private String cambioAutomatico;
    private String direcao;
    private String som;

    public VeiculoPasseio(int numPessoas, boolean possuemAR, 
            String cambioAutomatico, String direcao, String som) {
        super();
        this.numPessoas = numPessoas;
        this.possuemAR = possuemAR;
        this.cambioAutomatico = cambioAutomatico;
        this.direcao = direcao;
        this.som = som;
    }
    
    public VeiculoPasseio() {
    }

    public int getNumPessoas() {
        return numPessoas;
    }

    public void setNumPessoas(int numPessoas) {
        this.numPessoas = numPessoas;
    }

    public boolean isPossuemAR() {
        return possuemAR;
    }

    public void setPossuemAR(boolean possuemAR) {
        this.possuemAR = possuemAR;
    }

    public String getCambioAutomatico() {
        return cambioAutomatico;
    }

    public void setCambioAutomatico(String cambioAutomatico) {
        this.cambioAutomatico = cambioAutomatico;
    }

    public String getDirecao() {
        return direcao;
    }

    public void setDirecao(String direcao) {
        this.direcao = direcao;
    }

    public String getSom() {
        return som;
    }

    public void setSom(String som) {
        this.som = som;
    }

    @Override
    public String toString() {
        return  super.toString() +"\nNúmero de Pessoas = " + numPessoas 
              + "\nPossuem AR = " + possuemAR 
              + "\nCambio Automatico = " + cambioAutomatico 
              + "\nDireção = " + direcao 
              + "\nSom = " + som;
    }
    
    
}
