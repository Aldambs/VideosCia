package prova_Alda;

public class VeiculoDePessoas {
    private int  numMaxPessoas;
    private boolean possuemAR;
    private String cambioAutomatico;
    private String direcao;
    private String som;
    private boolean banheiro;

    public VeiculoDePessoas(int numMaxPessoas, boolean possuemAR, 
            String cambioAutomatico, String direcao, String som, boolean banheiro) {
        super();
        this.numMaxPessoas = numMaxPessoas;
        this.possuemAR = possuemAR;
        this.cambioAutomatico = cambioAutomatico;
        this.direcao = direcao;
        this.som = som;
        this.banheiro = banheiro;
    }
       
    public VeiculoDePessoas() {
    }

    public int getNumMaxPessoas() {
        return numMaxPessoas;
    }

    public void setNumMaxPessoas(int numMaxPessoas) {
        this.numMaxPessoas = numMaxPessoas;
    }

    public boolean isPossuemAR() {
        return possuemAR;
    }

    public void setPossuemAR(boolean possuemAR) {
        this.possuemAR = possuemAR;
    }

    public String getCambioAutomatico() {
        return cambioAutomatico;
    }

    public void setCambioAutomatico(String cambioAutomatico) {
        this.cambioAutomatico = cambioAutomatico;
    }

    public String getDirecao() {
        return direcao;
    }

    public void setDirecao(String direcao) {
        this.direcao = direcao;
    }

    public String getSom() {
        return som;
    }

    public void setSom(String som) {
        this.som = som;
    }

    public boolean isBanheiro() {
        return banheiro;
    }

    public void setBanheiro(boolean banheiro) {
        this.banheiro = banheiro;
    }

    @Override
    public String toString() {
        return " \nNúmero máximo de Pessoas = " + numMaxPessoas 
              + "\nPossuem AR = " + possuemAR 
              + "\nCambio Automatico = " + cambioAutomatico 
              + "\nDireção = " + direcao 
              + "\nSom = " + som
              + "\nBanheiro = " + banheiro;
    }
    
    
}
