/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.io;

import br.com.io.form.FormCad;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author geoleite
 */
public class AppIO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //exemploTexto();
        //exemploObjeto();
        forms();
    }

    public static void forms() {
        FormCad formCad = new FormCad();
        formCad.setVisible(true);
        
    }
    public static void exemploObjeto() {
        try {

            Arquivos arq = new Arquivos();
            arq.setNome("geo.txt");
            arq.setPath("/Users/geoleite");
            Aluno alu = new Aluno();
            alu.setDtNascimento(new Date());
            alu.setFone("98127391");
            alu.setNome("EU");
            alu.setMatricula("1231");
            List<Aluno> list = new ArrayList<Aluno>();
            
            List<Nota> listNota = new ArrayList<Nota>();
            Nota nota = new Nota();
            nota.setValor(10);
            listNota.add(nota);
            alu.setNotas(listNota);
            
            list.add(alu);
            alu = new Aluno();
            alu.setDtNascimento(new Date());
            alu.setFone("98127391");
            alu.setNome("TU");
            alu.setMatricula("1231");
            list.add(alu);
            arq.salvarObjeto(list);


//            List list2 = (List) arq.lerObjeto();
//            for (int i = 0; i < list2.size(); i++) {
//                Aluno a = (Aluno)list2.get(i);
//                System.out.println(a.getNome());
//            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void exemploTexto() {
        // TODO code application logic here
        try {

            String txt = "Salvando meu primeiro arquivo";
            Arquivos arq = new Arquivos();
            arq.setNome("geo.txt");
            arq.setPath("/Users/geoleite");
            //arq.salvar(txt);
            String retorno = arq.lerTexto();
            System.out.println(retorno);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
